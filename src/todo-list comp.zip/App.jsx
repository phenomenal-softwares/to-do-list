import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import TaskForm from './components/TaskForm';
import LoadingScreen from './components/LoadingScreen';
import ErrorBoundary from './components/ErrorBoundary';
import { FaMoon, FaSun, FaBars } from 'react-icons/fa';
import TasksPage from './components/TasksPage';
import OverlayMenu from './components/OverlayMenu'; // Import OverlayMenu component

const App = () => {
  const [tasks, setTasks] = useState([]);
  const [filter, setFilter] = useState('Pending'); // Default to 'Pending' filter
  const [theme, setTheme] = useState('light');
  const [hasLoaded, setHasLoaded] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false); // Track the state of the overlay menu

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 5000);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    try {
      const savedTasks = JSON.parse(localStorage.getItem('tasks')) || [];
      if (Array.isArray(savedTasks)) {
        setTasks(savedTasks);
      }
    } catch (error) {
      console.error('Failed to load tasks:', error);
    }
    setHasLoaded(true);
  }, []);

  useEffect(() => {
    if (hasLoaded) {
      localStorage.setItem('tasks', JSON.stringify(tasks));
    }
  }, [tasks, hasLoaded]);

  // Delete tasks at 12am if they are past their set days
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const updatedTasks = tasks.filter((task) => {
        const taskAge = Math.floor((now - new Date(task.createdDate)) / (1000 * 60 * 60 * 24));
        if (taskAge >= task.repeatDays) return false;
        if (taskAge >= 1 && task.completed) {
          task.completed = false;
        }
        return true;
      });
      setTasks(updatedTasks);
    }, 1000 * 60 * 60); // Check every hour

    return () => clearInterval(interval);
  }, [tasks]);

  const addTask = (newTask) => {
    const taskWithId = { ...newTask, id: Date.now(), subtasks: [] };
    setTasks([...tasks, taskWithId]);
  };

  const toggleCompletion = (taskId) => {
    setTasks((prevTasks) =>
      prevTasks.map((task) => {
        if (task.id === taskId) {
          return { ...task, completed: !task.completed };
        }
        return task;
      })
    );
  };

  const addSubtask = (taskId, subtaskName) => {
    setTasks((prevTasks) =>
      prevTasks.map((task) => {
        if (task.id === taskId) {
          return {
            ...task,
            subtasks: [...task.subtasks, { id: Date.now(), task: subtaskName, completed: false }],
          };
        }
        return task;
      })
    );
  };

  const toggleSubtaskCompletion = (taskId, subtaskId) => {
    setTasks((prevTasks) =>
      prevTasks.map((task) => {
        if (task.id === taskId) {
          const updatedSubtasks = task.subtasks.map((subtask) => {
            if (subtask.id === subtaskId) {
              return { ...subtask, completed: !subtask.completed };
            }
            return subtask;
          });
          return { ...task, subtasks: updatedSubtasks };
        }
        return task;
      })
    );
  };

  const deleteTask = (taskId) => {
    setTasks((prevTasks) => prevTasks.filter((task) => task.id !== taskId));
  };

  const deleteSubtask = (taskId, subtaskId) => {
    setTasks((prevTasks) =>
      prevTasks.map((task) => {
        if (task.id === taskId) {
          const updatedSubtasks = task.subtasks.filter((subtask) => subtask.id !== subtaskId);
          return { ...task, subtasks: updatedSubtasks };
        }
        return task;
      })
    );
  };

  const editTask = (taskId, newTask) => {
    setTasks((prevTasks) =>
      prevTasks.map((task) => {
        if (task.id === taskId) {
          return { ...task, task: newTask };
        }
        return task;
      })
    );
  };

  const editSubtask = (taskId, subtaskId, newSubtask) => {
    setTasks((prevTasks) =>
      prevTasks.map((task) => {
        if (task.id === taskId) {
          const updatedSubtasks = task.subtasks.map((subtask) => {
            if (subtask.id === subtaskId) {
              return { ...subtask, task: newSubtask };
            }
            return subtask;
          });
          return { ...task, subtasks: updatedSubtasks };
        }
        return task;
      })
    );
  };

  const filteredTasks = tasks.filter((task) => {
    if (filter === 'Completed') return task.completed;
    if (filter === 'Pending') return !task.completed;
    return true;
  });

  const completedCount = tasks.filter((task) => task.completed).length;
  const pendingCount = tasks.filter((task) => !task.completed).length;

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    document.body.className = newTheme;
  };

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  if (isLoading) {
    return <LoadingScreen />;
  }

  return (
    <Router>
      <div className={`container ${theme}`}>
        <header className="header">
          <h1>Priorify</h1>
          <div className="header-buttons">
            <button className="theme-toggle" onClick={toggleTheme}>
              {theme === 'light' ? <FaMoon /> : <FaSun />}
            </button>
            <button className="menu-toggle" onClick={toggleMenu}>
              <FaBars />
            </button>
          </div>
        </header>
        {menuOpen && (
          <OverlayMenu onClose={toggleMenu} />
        )}
        <ErrorBoundary>
          <Routes>
            <Route 
              path="/task-form" 
              element={<TaskForm addTask={addTask} />} 
            />
            <Route 
              path="/" 
              element={<TasksPage 
                tasks={filteredTasks}
                toggleCompletion={toggleCompletion}
                deleteTask={deleteTask}
                addSubtask={addSubtask}
                toggleSubtaskCompletion={toggleSubtaskCompletion}
                deleteSubtask={deleteSubtask}
                editTask={editTask}
                editSubtask={editSubtask}
                filter={filter}
                setFilter={setFilter}
                completedCount={completedCount}
                pendingCount={pendingCount}
                theme={theme}
                toggleTheme={toggleTheme}
              />} 
            />
            <Route 
              path="/tasks" 
              element={<TasksPage 
                tasks={filteredTasks}
                toggleCompletion={toggleCompletion}
                deleteTask={deleteTask}
                addSubtask={addSubtask}
                toggleSubtaskCompletion={toggleSubtaskCompletion}
                deleteSubtask={deleteSubtask}
                editTask={editTask}
                editSubtask={editSubtask}
                filter={filter}
                setFilter={setFilter}
                completedCount={completedCount}
                pendingCount={pendingCount}
                theme={theme}
                toggleTheme={toggleTheme}
              />} 
            />
          </Routes>
        </ErrorBoundary>
      </div>
    </Router>
  );
};

export default App;
