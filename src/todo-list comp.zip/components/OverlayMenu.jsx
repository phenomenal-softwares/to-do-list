import React, { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { FaTimes } from 'react-icons/fa';

const OverlayMenu = ({ onClose }) => {
  const overlayRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (overlayRef.current && !overlayRef.current.contains(event.target)) {
        onClose();
      }
    };

    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [onClose]);

  return (
    <div className="overlay-top-card" ref={overlayRef}>
      <button className="close-button" onClick={onClose}>
        <FaTimes />
      </button>
      <nav>
        <ul>
          <li><Link to="/tasks" onClick={onClose}>Set New Goal</Link></li>
          <li><Link to="/tasks" onClick={onClose}>View Goals</Link></li>
          <li><Link to="/stats" onClick={onClose}>Stats</Link></li>
          <li><Link to="/achievements" onClick={onClose}>Achievements</Link></li>
        </ul>
      </nav>
    </div>
  );
};

export default OverlayMenu;
