import React from 'react';
import { Link } from 'react-router-dom';
import { FaHome } from 'react-icons/fa';

const Filter = ({ filter, setFilter, completedCount, pendingCount }) => {
  return (
    <div className="filter-buttons">
      <Link to="/">
        <button className="home-button">
          <FaHome title="Back to Home" />
        </button>
      </Link>
      <button
        className={filter === 'Pending' ? 'active' : ''}
        onClick={() => setFilter('Pending')}
      >
        Pending <sup>{pendingCount}</sup>
      </button>
      <button
        className={filter === 'Completed' ? 'active' : ''}
        onClick={() => setFilter('Completed')}
      >
        Completed <sup>{completedCount}</sup>
      </button>
    </div>
  );
};

export default Filter;
