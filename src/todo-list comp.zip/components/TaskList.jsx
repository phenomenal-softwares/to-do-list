import React, { useState } from 'react';
import { FaTrashAlt, FaRedo, FaSort, FaPlus, FaEdit } from 'react-icons/fa';

const TaskList = ({ tasks, toggleCompletion, deleteTask, theme, filter, addSubtask, toggleSubtaskCompletion, deleteSubtask, editTask, editSubtask }) => {
  const [sortOrder, setSortOrder] = useState('asc'); // Default sort order
  const [editingTask, setEditingTask] = useState(null); // Track editing task
  const [editingSubtask, setEditingSubtask] = useState({}); // Track editing subtask

  const formatTime = (time24) => {
    if (!time24) return 'N/A'; // Handle undefined time
    const [hours, minutes] = time24.split(':');
    const period = +hours >= 12 ? 'pm' : 'am';
    const hours12 = +hours % 12 || 12;
    return `${hours12}:${minutes} ${period}`;
  };

  const handleEditTask = (taskId) => {
    const newTask = prompt("Edit your task:");
    if (newTask) {
      editTask(taskId, newTask);
    }
    setEditingTask(null);
  };

  const handleEditSubtask = (taskId, subtaskId) => {
    const newSubtask = prompt("Edit your sub-goal:");
    if (newSubtask) {
      editSubtask(taskId, subtaskId, newSubtask);
    }
    setEditingSubtask({});
  };

  const sortedTasks = [...tasks].sort((a, b) => {
    const timeA = new Date(`1970-01-01T${a.time}Z`).getTime();
    const timeB = new Date(`1970-01-01T${b.time}Z`).getTime();
    return sortOrder === 'asc' ? timeA - timeB : timeB - timeA;
  });

  const filteredTasks = sortedTasks.filter(task => {
    if (filter === 'Completed') return task.completed;
    if (filter === 'Pending') return !task.completed;
    return true;
  });

  const toggleSortOrder = () => {
    setSortOrder(prevOrder => (prevOrder === 'asc' ? 'desc' : 'asc'));
  };

  return (
    <div>
      <h2>Today</h2>
      <button className="sort-button" onClick={toggleSortOrder}>
        <FaSort /> Sort by Time ({sortOrder === 'asc' ? 'Ascending' : 'Descending'})
      </button>
      {filteredTasks.length === 0 ? (
        <p className="no-tasks-message">
          {filter === 'Pending' ? 'No pending tasks. What goals do you want to achieve today?' : 
          'No goals completed today. You can do it!'}
        </p>
      ) : (
        <ul className={`task-list ${theme}`}>
          {filteredTasks.map((task) => (
            <li key={task.id} className="task-item">
              <div className="main-task">
                <input
                  type="checkbox"
                  id="task-complete"
                  checked={task.completed}
                  onChange={() => toggleCompletion(task.id)}
                /> 
                <span style={{ textDecoration: task.completed ? 'line-through' : 'none' }}>
                  I will <strong>{task.task}</strong> at <strong>{formatTime(task.time)}</strong> <strong>{task.location}</strong>
                </span>
                <button
                  className="edit-button"
                  onClick={() => handleEditTask(task.id)}
                  title="Edit Task"
                >
                  <FaEdit />
                </button>
                <button
                  className="delete-button"
                  onClick={() => deleteTask(task.id)}
                  title="Delete Task"
                >
                  <FaTrashAlt />
                </button>
              </div>
              <div className="task-repetition">
                <FaRedo />
                <span>{task.repeatDays} {task.repeatDays === 1 ? 'day' : 'days'}</span>
              </div>
              <div className="subtasks">
                <ol>
                  {(task.subtasks || []).map((subtask) => (
                    <li key={subtask.id} className="subtask-item">
                      <input
                        type="checkbox"
                        checked={subtask.completed}
                        onChange={() => toggleSubtaskCompletion(task.id, subtask.id)}
                      />
                      <span style={{ textDecoration: subtask.completed ? 'line-through' : 'none', textAlign: 'left' }}>
                        I will <strong>{subtask.task}</strong>
                      </span>
                      <button
                        className="edit-button"
                        onClick={() => handleEditSubtask(task.id, subtask.id)}
                        title="Edit Subtask"
                      >
                        <FaEdit />
                      </button>
                      <button
                        className="delete-button"
                        onClick={() => deleteSubtask(task.id, subtask.id)}
                        title="Delete Subtask"
                      >
                        <FaTrashAlt />
                      </button>
                    </li>
                  ))}
                </ol>
                <button
                  className="add-subtask-button"
                  onClick={(e) => {
                    e.stopPropagation();
                    const subtaskName = prompt("Enter sub-goal:");
                    if (subtaskName) {
                      addSubtask(task.id, subtaskName);
                    }
                  }}
                  disabled={task.completed} // Disable button if task is completed
                  title={task.completed ? 'Task is completed' : 'Add Sub-goal'}
                >
                  <FaPlus /> Add Sub-goal
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default TaskList;
